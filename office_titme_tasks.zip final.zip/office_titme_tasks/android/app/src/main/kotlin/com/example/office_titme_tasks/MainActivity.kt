package com.example.office_titme_tasks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
