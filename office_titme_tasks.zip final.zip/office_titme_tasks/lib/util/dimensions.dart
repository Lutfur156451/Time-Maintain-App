


class Dimensions{


  static double FONT_SIZE_12 = 12;
  static double FONT_SIZE_14 = 14;


  static const double RADIUS_4 = 4.0;
  static const double RADIUS_8 = 8.0;
  static const double RADIUS_12 = 12.0;
  static const double RADIUS_16 = 16.0;
  static const double RADIUS_20 = 20.0;
  static const double RADIUS_50 = 50.0;

}