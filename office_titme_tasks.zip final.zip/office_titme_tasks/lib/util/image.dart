class Images {
  static const String logo = 'assets/logo.png';
  static const String clock = 'assets/json/Clock.json';


}